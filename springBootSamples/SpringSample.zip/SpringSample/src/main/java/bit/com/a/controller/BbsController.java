package bit.com.a.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import bit.com.a.dto.BbsDto;
import bit.com.a.dto.BbsParam;
import bit.com.a.service.BbsService;

@RestController
public class BbsController {
	@Autowired
	BbsService service;
	
	@RequestMapping(value="/bbslistData", method = {RequestMethod.GET, RequestMethod.POST})
	public List<BbsDto> bbslistData(BbsParam param){
		System.out.println("BbsController bbslistData() " + new Date());
		// paging 처리
				int sn = param.getPage();
				int start = sn * 10 + 1;	// 1 	11
				int end = (sn + 1) * 10; 	// 10   20
				
				param.setStart(start);
				param.setEnd(end);
		List<BbsDto> list = service.bbslistData(param);
		//System.out.println(list.toString());
		
		
		return list;
		
	}
	
	@RequestMapping(value="/bbslistCount", method = {RequestMethod.GET, RequestMethod.POST})
	public int bbslistCount(BbsParam param) {
		int count = service.bbslistCount(param);
		return count;
	}
	
	@RequestMapping(value="/bbsdetail", method = {RequestMethod.GET, RequestMethod.POST})
	public BbsDto bbsdetail(int seq) {
		BbsDto bbs = service.bbsdetail(seq);
		service.readcount(seq);
		return bbs;
	}
	
	@RequestMapping(value="/bbswriteAf", method = {RequestMethod.GET, RequestMethod.POST})
	public String bbswriteAf(BbsDto dto) {
		
		boolean b = service.bbswriteAf(dto);
		if(b) {
			String msg = "글작성성공";
			return msg;
		} else {
			String msg = "글작성실패";
			return msg;
		}
	}
	
}
